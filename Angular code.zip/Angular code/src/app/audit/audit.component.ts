import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';

import { User } from '../_models';
import { UserService } from '../_services';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
@Component({templateUrl: 'audit.component.html'})
export class AuditComponent implements OnInit {
    users: User[] = [];
   
    constructor(private userService: UserService,private router:Router) {}

    ngOnInit() {
        this.userService.getAll().pipe(first()).subscribe(users => { 
            this.users = users; 
            let currentUser=JSON.parse(localStorage.getItem("currentUser"));
            users.forEach((user)=>{
                
                if(user.username===currentUser.username ){
                    if(user.logInTime===null){
                     console.log("do nothing")
                
               }
                else{
                    user.logInTime=new Date();
                    user.logInTime=user.logInTime.getTime();
                    console.log("setting login time")}
                }
              
            })
        });
        
       

    }
    goToHomePage(){
        this.router.navigate(['/']);
    }
}