﻿import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { setFlagsFromString } from 'v8';

import { User } from '../_models';
import { UserService } from '../_services';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Component({templateUrl: 'home.component.html'})
export class HomeComponent implements OnInit {
    currentUser: User;
    users: User[] = [];
    isAdmin:Boolean;
    constructor(private userService: UserService,private router:Router) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
      
    }

    ngOnInit() {
        this.loadAllUsers();
        this.isAdmin=this.currentUser.role==="Admin"?true:false;
    }

    deleteUser(id: number) {
        this.userService.delete(id).pipe(first()).subscribe(() => { 
            this.loadAllUsers() 
        });
    }

    private loadAllUsers() {
        this.userService.getAll().pipe(first()).subscribe(users => { 
            this.users = users; 
            let currentUser=JSON.parse(localStorage.getItem("currentUser"));
            users.forEach((user)=>{
                console.log(user.username+" "+currentUser.username )
                if(user.username===currentUser.username ){
                    if(user.logInTime===null){
                     console.log("do nothing")
                
               }
                else{
                    user.logInTime=new Date();
                    user.logInTime=user.logInTime.getTime();
                    console.log("setting login time")}
                    localStorage.setItem('users',JSON.stringify(users))
                }
              
            })
        });
    }
    goToAuditPage(){
        this.router.navigate(['/audit']);
    }
}